function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6L8IXf6RMTl":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

